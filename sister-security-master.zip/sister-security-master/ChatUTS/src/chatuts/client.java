/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chatuts;

/**
 *
 * @author cynux
 */
import java.io.*;
import java.net.*;
public class client implements Runnable{
        // clientClient:   client socket

// os: the output   stream
// is: the input   stream
static Socket clientSocket = null;
static PrintStream os = null;
static BufferedReader is = null;

}
