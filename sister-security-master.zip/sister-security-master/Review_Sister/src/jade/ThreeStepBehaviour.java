/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jade;

/**
 *
 * @author cynux
 */
public class ThreeStepBehaviour {
//    private int step = 0;
//    public void action(){
//        switch (step){
//            case 0:
//                //perform operation x
//             step++;
//                break;
//            case 1:
//                //perform operation y
//                step+:
//                break;
//        }
//    }
}
